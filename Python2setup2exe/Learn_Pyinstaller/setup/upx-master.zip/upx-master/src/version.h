#define UPX_VERSION_HEX         0x035d00        /* 03.93.00 */
#define UPX_VERSION_STRING      "3.93"
#define UPX_VERSION_STRING4     "3.93"
#define UPX_VERSION_DATE        "Jan 29th 2017"
#define UPX_VERSION_DATE_ISO    "2017-01-29"
#define UPX_VERSION_YEAR        "2017"

/* vim:set ts=4 sw=4 et: */
